  let slideTitle = document.querySelector('#olimpTitle');
  let slideDescription = document.querySelector('#olimpDescription');
  let slideImg =document.querySelector('#slideImg');
  let slideTitle2 = document.querySelector('#olimpTitle2');
  let slideDescription2 = document.querySelector('#olimpDescription2');
  let slideImg2 = document.querySelector('#slideImg2');
  leftButton.onclick = function () {
    slideTitle.innerHTML = "ССК “КОЛИЗЕЙ”";
    slideDescription.innerHTML = "Световое оформление форума “Куртки-2021”";
    slideImg.style.backgroundImage = "url(img/content/content-projects-2.png)";
    slideTitle2.innerHTML = "ССК “КОЛИЗЕЙ”";
    slideDescription2.innerHTML = "Световое оформление форума “Куртки-2021”";
    slideImg2.style.backgroundImage = "url(img/content/content-projects-1.png)";
  },
  rightButton.onclick = function () {
    slideTitle.innerHTML = "ССК “ОЛИМП”";
    slideDescription.innerHTML = "Световое оформление форума “Шубы-2019”";
    slideImg.style.backgroundImage = "url(img/content/content-projects-1.png)";
    slideTitle2.innerHTML = "ССК “ОЛИМП”";
    slideDescription2.innerHTML = "Световое оформление форума “Шубы-2019”";
    slideImg2.style.backgroundImage = "url(img/content/content-projects-2.png)";
  }
let robe = document.querySelectorAll('#robe');
let compulite = document.querySelectorAll('#compulite');

  Compulite.onclick = function () {
    for (let elem of robe)
    elem.style.opacity='0';
    for (let elem of compulite)
    elem.style.opacity='1';
  },
  Robe.onclick = function () {
    for (let elem of robe)
    elem.style.opacity='1';
    for (let elem of compulite)
    elem.style.opacity='0';
  };
  
